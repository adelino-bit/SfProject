<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class GestionAllocationController extends AbstractController
{
    /**
     * @Route("/", name="home")
     */
    public function index()
    {
        return $this->render('gestion_allocation/index.html.twig', [
            'controller_name' => 'Allocaton Chambre',
        ]);
    }
}
